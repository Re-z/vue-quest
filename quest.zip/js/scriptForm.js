// intlTel
!function(a){var b=function(a,b,c){"use strict";return function(){function c(a,b){if(!(a instanceof b))throw new TypeError("Cannot call a class as a function")}function d(a,b){for(var c=0;c<b.length;c++){var d=b[c];d.enumerable=d.enumerable||!1,d.configurable=!0,"value"in d&&(d.writable=!0),Object.defineProperty(a,d.key,d)}}function e(a,b,c){return b&&d(a.prototype,b),c&&d(a,c),a}for(var f=[["Afghanistan (‫افغانستان‬‎)","af","93"],["Albania (Shqipëri)","al","355"],["Algeria (‫الجزائر‬‎)","dz","213"],["American Samoa","as","1684"],["Andorra","ad","376"],["Angola","ao","244"],["Anguilla","ai","1264"],["Antigua and Barbuda","ag","1268"],["Argentina","ar","54"],["Armenia (Հայաստան)","am","374"],["Aruba","aw","297"],["Australia","au","61",0],["Austria (Österreich)","at","43"],["Azerbaijan (Azərbaycan)","az","994"],["Bahamas","bs","1242"],["Bahrain (‫البحرين‬‎)","bh","973"],["Bangladesh (বাংলাদেশ)","bd","880"],["Barbados","bb","1246"],["Belarus (Беларусь)","by","375"],["Belgium (België)","be","32"],["Belize","bz","501"],["Benin (Bénin)","bj","229"],["Bermuda","bm","1441"],["Bhutan (འབྲུག)","bt","975"],["Bolivia","bo","591"],["Bosnia and Herzegovina (Босна и Херцеговина)","ba","387"],["Botswana","bw","267"],["Brazil (Brasil)","br","55"],["British Indian Ocean Territory","io","246"],["British Virgin Islands","vg","1284"],["Brunei","bn","673"],["Bulgaria (България)","bg","359"],["Burkina Faso","bf","226"],["Burundi (Uburundi)","bi","257"],["Cambodia (កម្ពុជា)","kh","855"],["Cameroon (Cameroun)","cm","237"],["Canada","ca","1",1,["204","226","236","249","250","289","306","343","365","387","403","416","418","431","437","438","450","506","514","519","548","579","581","587","604","613","639","647","672","705","709","742","778","780","782","807","819","825","867","873","902","905"]],["Cape Verde (Kabu Verdi)","cv","238"],["Caribbean Netherlands","bq","599",1],["Cayman Islands","ky","1345"],["Central African Republic (République centrafricaine)","cf","236"],["Chad (Tchad)","td","235"],["Chile","cl","56"],["China (中国)","cn","86"],["Christmas Island","cx","61",2],["Cocos (Keeling) Islands","cc","61",1],["Colombia","co","57"],["Comoros (‫جزر القمر‬‎)","km","269"],["Congo (DRC) (Jamhuri ya Kidemokrasia ya Kongo)","cd","243"],["Congo (Republic) (Congo-Brazzaville)","cg","242"],["Cook Islands","ck","682"],["Costa Rica","cr","506"],["Côte d’Ivoire","ci","225"],["Croatia (Hrvatska)","hr","385"],["Cuba","cu","53"],["Curaçao","cw","599",0],["Cyprus (Κύπρος)","cy","357"],["Czech Republic (Česká republika)","cz","420"],["Denmark (Danmark)","dk","45"],["Djibouti","dj","253"],["Dominica","dm","1767"],["Dominican Republic (República Dominicana)","do","1",2,["809","829","849"]],["Ecuador","ec","593"],["Egypt (‫مصر‬‎)","eg","20"],["El Salvador","sv","503"],["Equatorial Guinea (Guinea Ecuatorial)","gq","240"],["Eritrea","er","291"],["Estonia (Eesti)","ee","372"],["Ethiopia","et","251"],["Falkland Islands (Islas Malvinas)","fk","500"],["Faroe Islands (Føroyar)","fo","298"],["Fiji","fj","679"],["Finland (Suomi)","fi","358",0],["France","fr","33"],["French Guiana (Guyane française)","gf","594"],["French Polynesia (Polynésie française)","pf","689"],["Gabon","ga","241"],["Gambia","gm","220"],["Georgia (საქართველო)","ge","995"],["Germany (Deutschland)","de","49"],["Ghana (Gaana)","gh","233"],["Gibraltar","gi","350"],["Greece (Ελλάδα)","gr","30"],["Greenland (Kalaallit Nunaat)","gl","299"],["Grenada","gd","1473"],["Guadeloupe","gp","590",0],["Guam","gu","1671"],["Guatemala","gt","502"],["Guernsey","gg","44",1],["Guinea (Guinée)","gn","224"],["Guinea-Bissau (Guiné Bissau)","gw","245"],["Guyana","gy","592"],["Haiti","ht","509"],["Honduras","hn","504"],["Hong Kong (香港)","hk","852"],["Hungary (Magyarország)","hu","36"],["Iceland (Ísland)","is","354"],["India (भारत)","in","91"],["Indonesia","id","62"],["Iran (‫ایران‬‎)","ir","98"],["Iraq (‫العراق‬‎)","iq","964"],["Ireland","ie","353"],["Isle of Man","im","44",2],["Israel (‫ישראל‬‎)","il","972"],["Italy (Italia)","it","39",0],["Jamaica","jm","1",4,["876","658"]],["Japan (日本)","jp","81"],["Jersey","je","44",3],["Jordan (‫الأردن‬‎)","jo","962"],["Kazakhstan (Казахстан)","kz","7",1],["Kenya","ke","254"],["Kiribati","ki","686"],["Kosovo","xk","383"],["Kuwait (‫الكويت‬‎)","kw","965"],["Kyrgyzstan (Кыргызстан)","kg","996"],["Laos (ລາວ)","la","856"],["Latvia (Latvija)","lv","371"],["Lebanon (‫لبنان‬‎)","lb","961"],["Lesotho","ls","266"],["Liberia","lr","231"],["Libya (‫ليبيا‬‎)","ly","218"],["Liechtenstein","li","423"],["Lithuania (Lietuva)","lt","370"],["Luxembourg","lu","352"],["Macau (澳門)","mo","853"],["Macedonia (FYROM) (Македонија)","mk","389"],["Madagascar (Madagasikara)","mg","261"],["Malawi","mw","265"],["Malaysia","my","60"],["Maldives","mv","960"],["Mali","ml","223"],["Malta","mt","356"],["Marshall Islands","mh","692"],["Martinique","mq","596"],["Mauritania (‫موريتانيا‬‎)","mr","222"],["Mauritius (Moris)","mu","230"],["Mayotte","yt","262",1],["Mexico (México)","mx","52"],["Micronesia","fm","691"],["Moldova (Republica Moldova)","md","373"],["Monaco","mc","377"],["Mongolia (Монгол)","mn","976"],["Montenegro (Crna Gora)","me","382"],["Montserrat","ms","1664"],["Morocco (‫المغرب‬‎)","ma","212",0],["Mozambique (Moçambique)","mz","258"],["Myanmar (Burma) (မြန်မာ)","mm","95"],["Namibia (Namibië)","na","264"],["Nauru","nr","674"],["Nepal (नेपाल)","np","977"],["Netherlands (Nederland)","nl","31"],["New Caledonia (Nouvelle-Calédonie)","nc","687"],["New Zealand","nz","64"],["Nicaragua","ni","505"],["Niger (Nijar)","ne","227"],["Nigeria","ng","234"],["Niue","nu","683"],["Norfolk Island","nf","672"],["North Korea (조선 민주주의 인민 공화국)","kp","850"],["Northern Mariana Islands","mp","1670"],["Norway (Norge)","no","47",0],["Oman (‫عُمان‬‎)","om","968"],["Pakistan (‫پاکستان‬‎)","pk","92"],["Palau","pw","680"],["Palestine (‫فلسطين‬‎)","ps","970"],["Panama (Panamá)","pa","507"],["Papua New Guinea","pg","675"],["Paraguay","py","595"],["Peru (Perú)","pe","51"],["Philippines","ph","63"],["Poland (Polska)","pl","48"],["Portugal","pt","351"],["Puerto Rico","pr","1",3,["787","939"]],["Qatar (‫قطر‬‎)","qa","974"],["Réunion (La Réunion)","re","262",0],["Romania (România)","ro","40"],["Russia (Россия)","ru","7",0],["Rwanda","rw","250"],["Saint Barthélemy","bl","590",1],["Saint Helena","sh","290"],["Saint Kitts and Nevis","kn","1869"],["Saint Lucia","lc","1758"],["Saint Martin (Saint-Martin (partie française))","mf","590",2],["Saint Pierre and Miquelon (Saint-Pierre-et-Miquelon)","pm","508"],["Saint Vincent and the Grenadines","vc","1784"],["Samoa","ws","685"],["San Marino","sm","378"],["São Tomé and Príncipe (São Tomé e Príncipe)","st","239"],["Saudi Arabia (‫المملكة العربية السعودية‬‎)","sa","966"],["Senegal (Sénégal)","sn","221"],["Serbia (Србија)","rs","381"],["Seychelles","sc","248"],["Sierra Leone","sl","232"],["Singapore","sg","65"],["Sint Maarten","sx","1721"],["Slovakia (Slovensko)","sk","421"],["Slovenia (Slovenija)","si","386"],["Solomon Islands","sb","677"],["Somalia (Soomaaliya)","so","252"],["South Africa","za","27"],["South Korea (대한민국)","kr","82"],["South Sudan (‫جنوب السودان‬‎)","ss","211"],["Spain (España)","es","34"],["Sri Lanka (ශ්‍රී ලංකාව)","lk","94"],["Sudan (‫السودان‬‎)","sd","249"],["Suriname","sr","597"],["Svalbard and Jan Mayen","sj","47",1],["Swaziland","sz","268"],["Sweden (Sverige)","se","46"],["Switzerland (Schweiz)","ch","41"],["Syria (‫سوريا‬‎)","sy","963"],["Taiwan (台灣)","tw","886"],["Tajikistan","tj","992"],["Tanzania","tz","255"],["Thailand (ไทย)","th","66"],["Timor-Leste","tl","670"],["Togo","tg","228"],["Tokelau","tk","690"],["Tonga","to","676"],["Trinidad and Tobago","tt","1868"],["Tunisia (‫تونس‬‎)","tn","216"],["Turkey (Türkiye)","tr","90"],["Turkmenistan","tm","993"],["Turks and Caicos Islands","tc","1649"],["Tuvalu","tv","688"],["U.S. Virgin Islands","vi","1340"],["Uganda","ug","256"],["Ukraine (Україна)","ua","380"],["United Arab Emirates (‫الإمارات العربية المتحدة‬‎)","ae","971"],["United Kingdom","gb","44",0],["United States","us","1",0],["Uruguay","uy","598"],["Uzbekistan (Oʻzbekiston)","uz","998"],["Vanuatu","vu","678"],["Vatican City (Città del Vaticano)","va","39",1],["Venezuela","ve","58"],["Vietnam (Việt Nam)","vn","84"],["Wallis and Futuna (Wallis-et-Futuna)","wf","681"],["Western Sahara (‫الصحراء الغربية‬‎)","eh","212",1],["Yemen (‫اليمن‬‎)","ye","967"],["Zambia","zm","260"],["Zimbabwe","zw","263"],["Åland Islands","ax","358",1]],g=0;g<f.length;g++){var h=f[g];f[g]={name:h[0],iso2:h[1],dialCode:h[2],priority:h[3]||0,areaCodes:h[4]||null}}a.intlTelInputGlobals={getInstance:function(b){var c=b.getAttribute("data-intl-tel-input-id");return a.intlTelInputGlobals.instances[c]},instances:{}};var i=0,j={allowDropdown:!0,autoHideDialCode:!0,autoPlaceholder:"polite",customContainer:"",customPlaceholder:null,dropdownContainer:null,excludeCountries:[],formatOnDisplay:!0,geoIpLookup:null,hiddenInput:"",initialCountry:"",localizedCountries:null,nationalMode:!0,onlyCountries:[],placeholderNumberType:"MOBILE",preferredCountries:["us","gb"],separateDialCode:!1,utilsScript:""},k=["800","822","833","844","855","866","877","880","881","882","883","884","885","886","887","888","889"];a.addEventListener("load",function(){a.intlTelInputGlobals.windowLoaded=!0});var l=function(a,b){for(var c=Object.keys(a),d=0;d<c.length;d++)b(c[d],a[c[d]])},m=function(b){l(a.intlTelInputGlobals.instances,function(c){a.intlTelInputGlobals.instances[c][b]()})},n=function(){function d(a,b){var e=this;c(this,d),this.id=i++,this.a=a,this.b=null,this.c=null;var f=b||{};this.d={},l(j,function(a,b){e.d[a]=f.hasOwnProperty(a)?f[a]:b}),this.e=Boolean(a.getAttribute("placeholder"))}return e(d,[{key:"_init",value:function(){var a=this;if(this.d.nationalMode&&(this.d.autoHideDialCode=!1),this.d.separateDialCode&&(this.d.autoHideDialCode=this.d.nationalMode=!1),this.g=/Android.+Mobile|webOS|iPhone|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),this.g&&(b.body.classList.add("iti-mobile"),this.d.dropdownContainer||(this.d.dropdownContainer=b.body)),"undefined"!=typeof Promise){var c=new Promise(function(b,c){a.h=b,a.i=c}),d=new Promise(function(b,c){a.i0=b,a.i1=c});this.promise=Promise.all([c,d])}else this.h=this.i=function(){},this.i0=this.i1=function(){};this.s={},this._b(),this._f(),this._h(),this._i(),this._i3()}},{key:"_b",value:function(){this._d(),this._d2(),this._e(),this.d.localizedCountries&&this._d0(),(this.d.onlyCountries.length||this.d.localizedCountries)&&this.p.sort(this._d1)}},{key:"_c",value:function(a,b,c){this.q.hasOwnProperty(b)||(this.q[b]=[]);var d=c||0;this.q[b][d]=a}},{key:"_d",value:function(){if(this.d.onlyCountries.length){var a=this.d.onlyCountries.map(function(a){return a.toLowerCase()});this.p=f.filter(function(b){return a.indexOf(b.iso2)>-1})}else if(this.d.excludeCountries.length){var b=this.d.excludeCountries.map(function(a){return a.toLowerCase()});this.p=f.filter(function(a){return-1===b.indexOf(a.iso2)})}else this.p=f}},{key:"_d0",value:function(){for(var a=0;a<this.p.length;a++){var b=this.p[a].iso2.toLowerCase();this.d.localizedCountries.hasOwnProperty(b)&&(this.p[a].name=this.d.localizedCountries[b])}}},{key:"_d1",value:function(a,b){return a.name.localeCompare(b.name)}},{key:"_d2",value:function(){this.q={};for(var a=0;a<this.p.length;a++){var b=this.p[a];if(this._c(b.iso2,b.dialCode,b.priority),b.areaCodes)for(var c=0;c<b.areaCodes.length;c++)this._c(b.iso2,b.dialCode+b.areaCodes[c])}}},{key:"_e",value:function(){this.preferredCountries=[];for(var a=0;a<this.d.preferredCountries.length;a++){var b=this.d.preferredCountries[a].toLowerCase(),c=this._y(b,!1,!0);c&&this.preferredCountries.push(c)}}},{key:"_e2",value:function(a,c,d){var e=b.createElement(a);return c&&l(c,function(a,b){return e.setAttribute(a,b)}),d&&d.appendChild(e),e}},{key:"_f",value:function(){this.a.setAttribute("autocomplete","off");var a="intl-tel-input";this.d.allowDropdown&&(a+=" allow-dropdown"),this.d.separateDialCode&&(a+=" separate-dial-code"),this.d.customContainer&&(a+=" ",a+=this.d.customContainer);var b=this._e2("div",{"class":a});if(this.a.parentNode.insertBefore(b,this.a),this.k=this._e2("div",{"class":"flag-container"},b),b.appendChild(this.a),this.selectedFlag=this._e2("div",{"class":"selected-flag",role:"combobox","aria-owns":"country-listbox"},this.k),this.l=this._e2("div",{"class":"iti-flag"},this.selectedFlag),this.d.separateDialCode&&(this.t=this._e2("div",{"class":"selected-dial-code"},this.selectedFlag)),this.d.allowDropdown&&(this.selectedFlag.setAttribute("tabindex","0"),this.u=this._e2("div",{"class":"iti-arrow"},this.selectedFlag),this.m=this._e2("ul",{"class":"country-list hide",id:"country-listbox","aria-expanded":"false",role:"listbox"}),this.preferredCountries.length&&(this._g(this.preferredCountries,"preferred"),this._e2("li",{"class":"divider",role:"separator","aria-disabled":"true"},this.m)),this._g(this.p,"standard"),this.d.dropdownContainer?(this.dropdown=this._e2("div",{"class":"intl-tel-input iti-container"}),this.dropdown.appendChild(this.m)):this.k.appendChild(this.m)),this.d.hiddenInput){var c=this.d.hiddenInput,d=this.a.getAttribute("name");if(d){var e=d.lastIndexOf("[");-1!==e&&(c="".concat(d.substr(0,e),"[").concat(c,"]"))}this.hiddenInput=this._e2("input",{type:"hidden",name:c}),b.appendChild(this.hiddenInput)}}},{key:"_g",value:function(a,b){for(var c="",d=0;d<a.length;d++){var e=a[d];c+="<li class='country ".concat(b,"' tabIndex='-1' id='iti-item-").concat(e.iso2,"' role='option' data-dial-code='").concat(e.dialCode,"' data-country-code='").concat(e.iso2,"'>"),c+="<div class='flag-box'><div class='iti-flag ".concat(e.iso2,"'></div></div>"),c+="<span class='country-name'>".concat(e.name,"</span>"),c+="<span class='dial-code'>+".concat(e.dialCode,"</span>"),c+="</li>"}this.m.insertAdjacentHTML("beforeend",c)}},{key:"_h",value:function(){var a=this.a.value,b=this._5(a),c=this._w(a),d=this.d,e=d.initialCountry,f=d.nationalMode,g=d.autoHideDialCode,h=d.separateDialCode;b&&!c?this._v(a):"auto"!==e&&(e?this._z(e.toLowerCase()):b&&c?this._z("us"):(this.j=this.preferredCountries.length?this.preferredCountries[0].iso2:this.p[0].iso2,a||this._z(this.j)),a||f||g||h||(this.a.value="+".concat(this.s.dialCode))),a&&this._u(a)}},{key:"_i",value:function(){this._j(),this.d.autoHideDialCode&&this._l(),this.d.allowDropdown&&this._i2(),this.hiddenInput&&this._i0()}},{key:"_i0",value:function(){var a=this;this._a14=function(){a.hiddenInput.value=a.getNumber()},this.a.form&&this.a.form.addEventListener("submit",this._a14)}},{key:"_i1",value:function(){for(var a=this.a;a&&"LABEL"!==a.tagName;)a=a.parentNode;return a}},{key:"_i2",value:function(){var a=this;this._a9=function(b){a.m.classList.contains("hide")?a.a.focus():b.preventDefault()};var b=this._i1();b&&b.addEventListener("click",this._a9),this._a10=function(){!a.m.classList.contains("hide")||a.a.disabled||a.a.readOnly||a._n()},this.selectedFlag.addEventListener("click",this._a10),this._a11=function(b){a.m.classList.contains("hide")&&-1!==["ArrowUp","ArrowDown"," ","Enter"].indexOf(b.key)&&(b.preventDefault(),b.stopPropagation(),a._n()),"Tab"===b.key&&a._2()},this.k.addEventListener("keydown",this._a11)}},{key:"_i3",value:function(){var b=this;this.d.utilsScript&&!a.intlTelInputUtils?a.intlTelInputGlobals.windowLoaded?a.intlTelInputGlobals.loadUtils(this.d.utilsScript):a.addEventListener("load",function(){a.intlTelInputGlobals.loadUtils(b.d.utilsScript)}):this.i0(),"auto"===this.d.initialCountry?this._i4():this.h()}},{key:"_i4",value:function(){a.intlTelInputGlobals.autoCountry?this.handleAutoCountry():a.intlTelInputGlobals.startedLoadingAutoCountry||(a.intlTelInputGlobals.startedLoadingAutoCountry=!0,"function"==typeof this.d.geoIpLookup&&this.d.geoIpLookup(function(b){a.intlTelInputGlobals.autoCountry=b.toLowerCase(),setTimeout(function(){return m("handleAutoCountry")})},function(){return m("rejectAutoCountryPromise")}))}},{key:"_j",value:function(){var a=this;this._a12=function(){a._v(a.a.value)&&a._8()},this.a.addEventListener("keyup",this._a12),this._a13=function(){setTimeout(a._a12)},this.a.addEventListener("cut",this._a13),this.a.addEventListener("paste",this._a13)}},{key:"_j2",value:function(a){var b=this.a.getAttribute("maxlength");return b&&a.length>b?a.substr(0,b):a}},{key:"_l",value:function(){var a=this;this._a8=function(){a._l2()},this.a.form&&this.a.form.addEventListener("submit",this._a8),this.a.addEventListener("blur",this._a8)}},{key:"_l2",value:function(){if("+"===this.a.value.charAt(0)){var a=this._m(this.a.value);a&&this.s.dialCode!==a||(this.a.value="")}}},{key:"_m",value:function(a){return a.replace(/\D/g,"")}},{key:"_m2",value:function(a){var c=b.createEvent("Event");c.initEvent(a,!0,!0),this.a.dispatchEvent(c)}},{key:"_n",value:function(){this.m.classList.remove("hide"),this.m.setAttribute("aria-expanded","true"),this._o(),this.b&&(this._x(this.b,!1),this._3(this.b,!0)),this._p(),this.u.classList.add("up"),this._m2("open:countrydropdown")}},{key:"_n2",value:function(a,b,c){c&&!a.classList.contains(b)?a.classList.add(b):!c&&a.classList.contains(b)&&a.classList.remove(b)}},{key:"_o",value:function(){var c=this;if(this.d.dropdownContainer&&this.d.dropdownContainer.appendChild(this.dropdown),!this.g){var d=this.a.getBoundingClientRect(),e=a.pageYOffset||b.documentElement.scrollTop,f=d.top+e,g=this.m.offsetHeight,h=f+this.a.offsetHeight+g<e+a.innerHeight,i=f-g>e;if(this._n2(this.m,"dropup",!h&&i),this.d.dropdownContainer){var j=!h&&i?0:this.a.offsetHeight;this.dropdown.style.top="".concat(f+j,"px"),this.dropdown.style.left="".concat(d.left+b.body.scrollLeft,"px"),this._a4=function(){return c._2()},a.addEventListener("scroll",this._a4)}}}},{key:"_o2",value:function(a){for(var b=a;b&&b!==this.m&&!b.classList.contains("country");)b=b.parentNode;return b===this.m?null:b}},{key:"_p",value:function(){var a=this;this._a0=function(b){var c=a._o2(b.target);c&&a._x(c,!1)},this.m.addEventListener("mouseover",this._a0),this._a1=function(b){var c=a._o2(b.target);c&&a._1(c)},this.m.addEventListener("click",this._a1);var c=!0;this._a2=function(){c||a._2(),c=!1},b.documentElement.addEventListener("click",this._a2);var d="",e=null;this._a3=function(b){b.preventDefault(),"ArrowUp"===b.key||"ArrowDown"===b.key?a._q(b.key):"Enter"===b.key?a._r():"Escape"===b.key?a._2():/^[a-zA-ZÀ-ÿ ]$/.test(b.key)&&(e&&clearTimeout(e),d+=b.key.toLowerCase(),a._s(d),e=setTimeout(function(){d=""},1e3))},b.addEventListener("keydown",this._a3)}},{key:"_q",value:function(a){var b="ArrowUp"===a?this.c.previousElementSibling:this.c.nextElementSibling;b&&(b.classList.contains("divider")&&(b="ArrowUp"===a?b.previousElementSibling:b.nextElementSibling),this._x(b,!0))}},{key:"_r",value:function(){this.c&&this._1(this.c)}},{key:"_s",value:function(a){for(var b=0;b<this.p.length;b++)if(this._t(this.p[b].name,a)){var c=this.m.querySelector("#iti-item-".concat(this.p[b].iso2));this._x(c,!1),this._3(c,!0);break}}},{key:"_t",value:function(a,b){return a.substr(0,b.length).toLowerCase()===b}},{key:"_u",value:function(b){var c=b;if(this.d.formatOnDisplay&&a.intlTelInputUtils&&this.s){var d=!this.d.separateDialCode&&(this.d.nationalMode||"+"!==c.charAt(0)),e=intlTelInputUtils.numberFormat,f=e.NATIONAL,g=e.INTERNATIONAL,h=d?f:g;c=intlTelInputUtils.formatNumber(c,this.s.iso2,h)}c=this._7(c),this.a.value=c}},{key:"_v",value:function(a){var b=a,c="1"===this.s.dialCode;b&&this.d.nationalMode&&c&&"+"!==b.charAt(0)&&("1"!==b.charAt(0)&&(b="1".concat(b)),b="+".concat(b));var d=this._5(b),e=this._m(b),f=null;if(d){var g=this.q[this._m(d)],h=-1!==g.indexOf(this.s.iso2),i="+1"===d&&e.length>=4;if(!("1"===this.s.dialCode&&this._w(e))&&(!h||i))for(var j=0;j<g.length;j++)if(g[j]){f=g[j];break}}else"+"===b.charAt(0)&&e.length?f="":b&&"+"!==b||(f=this.j);return null!==f&&this._z(f)}},{key:"_w",value:function(a){var b=this._m(a);if("1"===b.charAt(0)){var c=b.substr(1,3);return-1!==k.indexOf(c)}return!1}},{key:"_x",value:function(a,b){var c=this.c;c&&c.classList.remove("highlight"),this.c=a,this.c.classList.add("highlight"),b&&this.c.focus()}},{key:"_y",value:function(a,b,c){for(var d=b?f:this.p,e=0;e<d.length;e++)if(d[e].iso2===a)return d[e];if(c)return null;throw new Error("No country data for '".concat(a,"'"))}},{key:"_z",value:function(a){var b=this.s.iso2?this.s:{};this.s=a?this._y(a,!1,!1):{},this.s.iso2&&(this.j=this.s.iso2),this.l.setAttribute("class","iti-flag ".concat(a));var c=a?"".concat(this.s.name,": +").concat(this.s.dialCode):"Unknown";if(this.selectedFlag.setAttribute("title",c),this.d.separateDialCode){var d=this.s.dialCode?"+".concat(this.s.dialCode):"";this.t.innerHTML=d,this.a.style.paddingLeft="".concat(this.selectedFlag.offsetWidth+6,"px")}if(this._0(),this.d.allowDropdown){var e=this.b;if(e&&(e.classList.remove("active"),e.setAttribute("aria-selected","false")),a){var f=this.m.querySelector("#iti-item-".concat(a));f.setAttribute("aria-selected","true"),f.classList.add("active"),this.b=f,this.m.setAttribute("aria-activedescendant",f.getAttribute("id"))}}return b.iso2!==a}},{key:"_0",value:function(){var b="aggressive"===this.d.autoPlaceholder||!this.e&&"polite"===this.d.autoPlaceholder;if(a.intlTelInputUtils&&b){var c=intlTelInputUtils.numberType[this.d.placeholderNumberType],d=this.s.iso2?intlTelInputUtils.getExampleNumber(this.s.iso2,this.d.nationalMode,c):"";d=this._7(d),"function"==typeof this.d.customPlaceholder&&(d=this.d.customPlaceholder(d,this.s)),this.a.setAttribute("placeholder",d)}}},{key:"_1",value:function(a){var b=this._z(a.getAttribute("data-country-code"));this._2(),this._4(a.getAttribute("data-dial-code"),!0),this.a.focus();var c=this.a.value.length;this.a.setSelectionRange(c,c),b&&this._8()}},{key:"_2",value:function(){this.m.classList.add("hide"),this.m.setAttribute("aria-expanded","false"),this.u.classList.remove("up"),b.removeEventListener("keydown",this._a3),b.documentElement.removeEventListener("click",this._a2),this.m.removeEventListener("mouseover",this._a0),this.m.removeEventListener("click",this._a1),this.d.dropdownContainer&&(this.g||a.removeEventListener("scroll",this._a4),this.dropdown.parentNode&&this.dropdown.parentNode.removeChild(this.dropdown)),this._m2("close:countrydropdown")}},{key:"_3",value:function(c,d){var e=this.m,f=a.pageYOffset||b.documentElement.scrollTop,g=e.offsetHeight,h=e.getBoundingClientRect().top+f,i=h+g,j=c.offsetHeight,k=c.getBoundingClientRect().top+f,l=k+j,m=k-h+e.scrollTop,n=g/2-j/2;if(k<h)d&&(m-=n),e.scrollTop=m;else if(l>i){d&&(m+=n);var o=g-j;e.scrollTop=m-o}}},{key:"_4",value:function(a,b){var c,d=this.a.value,e="+".concat(a);if("+"===d.charAt(0)){var f=this._5(d);c=f?d.replace(f,e):e}else{if(this.d.nationalMode||this.d.separateDialCode)return;if(d)c=e+d;else{if(!b&&this.d.autoHideDialCode)return;c=e}}this.a.value=c}},{key:"_5",value:function(a){var b="";if("+"===a.charAt(0))for(var c="",d=0;d<a.length;d++){var e=a.charAt(d);if(!isNaN(parseInt(e,10))&&(c+=e,this.q[c]&&(b=a.substr(0,d+1)),4===c.length))break}return b}},{key:"_6",value:function(){var a=this.a.value.trim(),b=this.s.dialCode,c=this._m(a),d="1"===c.charAt(0)?c:"1".concat(c);return(this.d.separateDialCode&&"+"!==a.charAt(0)?"+".concat(b):a&&"+"!==a.charAt(0)&&"1"!==a.charAt(0)&&b&&"1"===b.charAt(0)&&4===b.length&&b!==d.substr(0,4)?b.substr(1):"")+a}},{key:"_7",value:function(a){var b=a;if(this.d.separateDialCode){var c=this._5(b);if(c){null!==this.s.areaCodes&&(c="+".concat(this.s.dialCode));var d=" "===b[c.length]||"-"===b[c.length]?c.length+1:c.length;b=b.substr(d)}}return this._j2(b)}},{key:"_8",value:function(){this._m2("countrychange")}},{key:"handleAutoCountry",value:function(){"auto"===this.d.initialCountry&&(this.j=a.intlTelInputGlobals.autoCountry,this.a.value||this.setCountry(this.j),this.h())}},{key:"handleUtils",value:function(){a.intlTelInputUtils&&(this.a.value&&this._u(this.a.value),this._0()),this.i0()}},{key:"destroy",value:function(){var b=this.a.form;if(this.d.allowDropdown){this._2(),this.selectedFlag.removeEventListener("click",this._a10),this.k.removeEventListener("keydown",this._a11);var c=this._i1();c&&c.removeEventListener("click",this._a9)}this.hiddenInput&&b&&b.removeEventListener("submit",this._a14),this.d.autoHideDialCode&&(b&&b.removeEventListener("submit",this._a8),this.a.removeEventListener("blur",this._a8)),this.a.removeEventListener("keyup",this._a12),this.a.removeEventListener("cut",this._a13),this.a.removeEventListener("paste",this._a13),this.a.removeAttribute("data-intl-tel-input-id");var d=this.a.parentNode;d.parentNode.insertBefore(this.a,d),d.parentNode.removeChild(d),delete a.intlTelInputGlobals.instances[this.id]}},{key:"getExtension",value:function(){return a.intlTelInputUtils?intlTelInputUtils.getExtension(this._6(),this.s.iso2):""}},{key:"getNumber",value:function(b){if(a.intlTelInputUtils){var c=this.s.iso2;return intlTelInputUtils.formatNumber(this._6(),c,b)}return""}},{key:"getNumberType",value:function(){return a.intlTelInputUtils?intlTelInputUtils.getNumberType(this._6(),this.s.iso2):-99}},{key:"getSelectedCountryData",value:function(){return this.s}},{key:"getValidationError",value:function(){if(a.intlTelInputUtils){var b=this.s.iso2;return intlTelInputUtils.getValidationError(this._6(),b)}return-99}},{key:"isValidNumber",value:function(){var b=this._6().trim(),c=this.d.nationalMode?this.s.iso2:"";return a.intlTelInputUtils?intlTelInputUtils.isValidNumber(b,c):null}},{key:"setCountry",value:function(a){var b=a.toLowerCase();this.l.classList.contains(b)||(this._z(b),this._4(this.s.dialCode,!1),this._8())}},{key:"setNumber",value:function(a){var b=this._v(a);this._u(a),b&&this._8()}},{key:"setPlaceholderNumberType",value:function(a){this.d.placeholderNumberType=a,this._0()}}]),d}();a.intlTelInputGlobals.getCountryData=function(){return f};var o=function(a,c,d){var e=b.createElement("script");e.onload=function(){m("handleUtils"),c&&c()},e.onerror=function(){m("rejectUtilsScriptPromise"),d&&d()},e.className="iti-load-utils",e.async=!0,e.src=a,b.body.appendChild(e)};return a.intlTelInputGlobals.loadUtils=function(b){if(!a.intlTelInputUtils&&!a.intlTelInputGlobals.startedLoadingUtilsScript){if(a.intlTelInputGlobals.startedLoadingUtilsScript=!0,"undefined"!=typeof Promise)return new Promise(function(a,c){return o(b,a,c)});o(b)}return null},a.intlTelInputGlobals.defaults=j,a.intlTelInputGlobals.version="15.1.0",function(b,c){var d=new n(b,c);return d._init(),b.setAttribute("data-intl-tel-input-id",d.id),a.intlTelInputGlobals.instances[d.id]=d,d}}()}(window,document);"object"==typeof module&&module.exports?module.exports=b:window.intlTelInput=b}();

const popup = function() {

  const body = document.querySelector('body');

  let popup = document.querySelector('.popup');

  if (!popup) {
    popup = document.createElement('div');
    popup.classList.add('popup');

    popup.innerHTML = `
      <div class="popup-wrapper">
        <div class="popup-btn-close"></div>
        <div class="popup-content"></div>
      </div>
    `;

    body.appendChild(popup);
  }

  let popupWrapper = popup.querySelector('.popup-wrapper');
  let popupBtnClose = popup.querySelector('.popup-btn-close');
  let popupText = popup.querySelector('.popup-content');

  let popupShow = function (textMessage) {
    if (textMessage) {
      popupText.innerHTML = `
        <div class="popup-text">
          <p>
            ${textMessage}
          </p>
        </div>
      `;
    }
    popup.classList.add('opened');
  };

  let popupHide = function (e) {
    if(e) {
      e.stopPropagation();
    }
    popup.classList.remove('opened');
  };

  popupBtnClose.addEventListener('click', popupHide);
  popup.addEventListener('click', popupHide);
  popupWrapper.addEventListener('click', function (e) {
    e.stopPropagation();
  });

  return popupShow;
};
const regForm = document.querySelector('#regForm');
const settingRegisterForm = (root, params) => {
  const checkValue = elem => elem.value.trim() !== '';
  const removeClassError = elem => {
    if (elem.classList.contains('error')) {
      elem.classList.remove('error');
      elem.removeEventListener('input', addClassErrorHandler);
      if (elem.classList.contains('select-country'))  {
        $(elem).off('select2:select', addClassErrorHandler);
      }
    }
  };

  const addClassErrorHandler = e => {
    removeClassError(e.currentTarget);
    hideError(e.currentTarget);
  };

  const addClassError = elem => {
    elem.classList.add('error');
    elem.addEventListener('input', addClassErrorHandler);
    elem.addEventListener('changeSelect', addClassErrorHandler);

    if (elem.classList.contains('select-country'))  {
      $(elem).on('select2:select', addClassErrorHandler);
    }
  };

  const showError = (inputField, message) => {
    let inputBlock = inputField;

    while (!inputBlock.classList.contains('form-input')) {
      inputBlock = inputBlock.parentElement;
    }

    let errorsBlock = inputBlock.querySelector('.errors-block');
    if (!errorsBlock) {
      errorsBlock = document.createElement('div');
      errorsBlock.classList.add('errors-block');
      inputBlock.appendChild(errorsBlock);
    }

    errorsBlock.textContent = message;
  };

  const hideError = inputField => {
    let inputBlock = inputField;

    while (!inputBlock.classList.contains('form-input')) {
      inputBlock = inputBlock.parentElement;
    }

    let errorsBlock = inputBlock.querySelector('.errors-block');
    if (errorsBlock && errorsBlock.textContent !== '') {
      errorsBlock.textContent = '';
    }
  };

  const getCookie = name => {
    let matches = document.cookie.match(new RegExp(
      "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
  };

  const popupShow = popup();

  // render form

  const regForm = document.createElement('form');
  regForm.classList.add('form');
  regForm.noValidate = true;
  regForm.setAttribute('action', root.getAttribute('data-action'));
  regForm.setAttribute('method', 'post');

  let fname = null;
  if (params && params.fname) {
    const fnameWrap = document.createElement('label');
    fnameWrap.classList.add('form-input');
    fname = document.createElement('input');
    fname.setAttribute('type', 'text');
    fname.setAttribute('name', 'first_name');
    fname.classList.add('form-control');
    if (window.translations && translations.yourName) {
      fname.setAttribute('placeholder', translations.yourName);
    } else {
      fname.setAttribute('placeholder', 'Enter Name');
    }
    fnameWrap.appendChild(fname);
    regForm.appendChild(fnameWrap);
  }

  const countrySelectWrap = document.createElement('div');
  countrySelectWrap.classList.add('form-input');
  const countrySelect = document.createElement('select');
  countrySelect.classList.add('select-country');
  countrySelect.setAttribute('name', 'select-country');
  if (window.translations && translations.selectCountry) {
    countrySelect.setAttribute('placeholder', translations.selectCountry);
  } else {
    countrySelect.setAttribute('placeholder', 'Select Country');
  }
  countrySelectWrap.appendChild(countrySelect);
  regForm.appendChild(countrySelectWrap);

  const emailWrap = document.createElement('label');
  emailWrap.classList.add('form-input');
  const email = document.createElement('input');
  email.setAttribute('type', 'email');
  email.setAttribute('name', 'email');
  email.classList.add('form-control');
  email.setAttribute('placeholder', 'E-mail');
  emailWrap.appendChild(email);
  regForm.appendChild(emailWrap);

  const passWrap = document.createElement('label');
  passWrap.classList.add('form-input');
  const passWrapper = document.createElement('span');
  passWrapper.classList.add('form-input-password-wrapper');
  const password = document.createElement('input');
  password.setAttribute('type', 'password');
  password.setAttribute('name', 'password');
  password.classList.add('form-control');
  if (window.translations && translations.password) {
    password.setAttribute('placeholder', translations.password);
  } else {
    password.setAttribute('placeholder', 'Password');
  }
  passWrapper.appendChild(password);
  passWrap.appendChild(passWrapper);
  regForm.appendChild(passWrap);

  const phoneWrap = document.createElement('div');
  phoneWrap.classList.add('form-input');
  const phoneWrapper = document.createElement('span');
  phoneWrapper.classList.add('form-input-phone');
  const phoneCode = document.createElement('input');
  phoneCode.setAttribute('type', 'text');
  phoneCode.setAttribute('name', 'phone-code');
  if (window.translations && translations.code) {
    phoneCode.setAttribute('placeholder', translations.code);
  } else {
    phoneCode.setAttribute('placeholder', 'Code');
  }
  phoneCode.readOnly = true;
  const phoneNum = document.createElement('input');
  phoneNum.setAttribute('type', 'tel');
  phoneNum.setAttribute('name', 'phone-num');
  if (window.translations && translations.phone) {
    phoneNum.setAttribute('placeholder', translations.phone);
  } else {
    phoneNum.setAttribute('placeholder', 'Phone');
  }
  phoneWrapper.appendChild(phoneCode);
  phoneWrapper.appendChild(phoneNum);
  phoneWrap.appendChild(phoneWrapper);
  regForm.appendChild(phoneWrap);

  const termsWrap = document.createElement('label');
  termsWrap.classList.add('form-input');
  termsWrap.classList.add('form-checkbox');
  const terms = document.createElement('input');
  terms.setAttribute('type', 'checkbox');
  terms.setAttribute('name', 'terms');
  const termsIcon = document.createElement('span');
  termsIcon.classList.add('form-checkbox-icon');
  const termsDescr = document.createElement('span');
  termsDescr.classList.add('form-checkbox-descr');
  if (window.translations && translations.termsDescr) {
    termsDescr.innerHTML = translations.termsDescr;
  } else {
    termsDescr.innerHTML = `
    By checking this box I agree to the Monfex
    <a href="https://www.monfex.com/privacy-policy" target="_blank">Privacy Policy</a>
    and
    <a href="https://www.monfex.com/terms-of-service" target="_blank">Terms of Service</a>.
  `;
  }
  termsWrap.appendChild(terms);
  termsWrap.appendChild(termsIcon);
  termsWrap.appendChild(termsDescr);
  regForm.appendChild(termsWrap);

  if (params && params.mailing) {
    const mailingWrap = document.createElement('label');
    mailingWrap.classList.add('form-input');
    mailingWrap.classList.add('form-checkbox');
    const mailing = document.createElement('input');
    mailing.setAttribute('type', 'checkbox');
    mailing.setAttribute('name', 'e_opt_in_email_status');
    mailing.checked = true;
    const mailingIcon = document.createElement('span');
    mailingIcon.classList.add('form-checkbox-icon');
    const mailingDescr = document.createElement('span');
    mailingDescr.classList.add('form-checkbox-descr');
    if (window.translations && translations.mailingDescr) {
      mailingDescr.innerHTML = translations.mailingDescr;
    } else {
      mailingDescr.innerHTML = `I agree to receive e-mail newsletters from Monfex`;
    }
    mailingWrap.appendChild(mailing);
    mailingWrap.appendChild(mailingIcon);
    mailingWrap.appendChild(mailingDescr);
    regForm.appendChild(mailingWrap);
  }

  const country = document.createElement('input');
  country.setAttribute('type', 'hidden');
  country.setAttribute('name', 'country');
  country.setAttribute('autocomplete', 'off');
  country.classList.add('input-hidden');
  regForm.appendChild(country);

  const phone = document.createElement('input');
  phone.setAttribute('type', 'hidden');
  phone.setAttribute('name', 'phone');
  phone.classList.add('input-hidden');
  regForm.appendChild(phone);

  const gcid = document.createElement('input');
  gcid.setAttribute('type', 'hidden');
  gcid.setAttribute('name', 'ga_cid');
  gcid.classList.add('input-hidden');
  regForm.appendChild(gcid);

  const uriQuery = document.createElement('input');
  uriQuery.setAttribute('type', 'hidden');
  uriQuery.setAttribute('name', 'uri_query');
  uriQuery.classList.add('input-hidden');
  regForm.appendChild(uriQuery);

  const affiliateCode = document.createElement('input');
  affiliateCode.setAttribute('type', 'hidden');
  affiliateCode.setAttribute('name', 'affiliate_code');
  affiliateCode.classList.add('input-hidden');
  regForm.appendChild(affiliateCode);

  const promoCode = document.createElement('input');
  promoCode.setAttribute('type', 'hidden');
  promoCode.setAttribute('name', 'promo_code');
  promoCode.classList.add('input-hidden');
  regForm.appendChild(promoCode);

  const partnerLink = document.createElement('input');
  partnerLink.setAttribute('type', 'hidden');
  partnerLink.setAttribute('name', 'partner_link');
  partnerLink.classList.add('input-hidden');
  regForm.appendChild(partnerLink);

  const mnfxRefId = document.createElement('input');
  mnfxRefId.setAttribute('type', 'hidden');
  mnfxRefId.setAttribute('name', 'mnfx_ref_id');
  regForm.appendChild(mnfxRefId);

  const platform = document.createElement('input');
  platform.setAttribute('type', 'hidden');
  platform.setAttribute('name', 'platform');
  platform.value = 'mxt';
  regForm.appendChild(platform);

  const btn = document.createElement('button');
  btn.setAttribute('type', 'submit');
  btn.classList.add('form-btn', 'btn', 'btn-success', 'btn-lg', 'w-100');
  btn.classList.add('btn');
  (window.translations && translations.btnDescr) ?
    btn.textContent = translations.btnDescr :
    btn.textContent = 'Join Now !';
  const loader = document.createElement('div');
  loader.innerHTML = `
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
  `;
  btn.appendChild(loader);
  regForm.appendChild(btn);

  root.appendChild(regForm);

  if (params && params.formDescr) {
    const loginLink = 'https://myaccount.monfex.com/#login';
    const formDescr = document.createElement('div');
    formDescr.classList.add('promo-form-descr');
    formDescr.innerHTML = (window.translations && translations.formDescr) ? translations.formDescr : `Already have a Monfex account? Please <a href="${loginLink}">login</a>.`;

    root.appendChild(formDescr);
  }

  // end render form

  const regExpName = /^(|[a-zA-Z\-\s]+)$/;
  const regExpEmail = /^[-.+_a-z0-9]+@(?:[a-z0-9][-a-z0-9]+\.)+[a-z]{2,6}$/i;
  const regExpPass = /(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z!@#$%^&*\/\-]{5,15}/;
  const regExpPass1 = /(?=.*[0-9])(?=.*[a-z])[0-9a-zA-Z!@#$%^&*\/\-]{5,15}/;
  const regExpPass2 = /(?=.*[0-9])(?=.*[A-Z])[0-9a-zA-Z!@#$%^&*\/\-]{5,15}/;
  const regExpPass3 = /(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z!@#$%^&*\/\-]{5,15}/;

  if (gcid) {
    let match = document.cookie.match('(?:^|;)\\s*_ga=([^;]*)');
    const raw = (match) ? decodeURIComponent(match[1]) : null;
    if (raw) {
      match = raw.match(/(\d+\.\d+)$/);
    }
    gcid.value = (match) ? match[1] : null;
  }

  const getParams = window.location.search.slice(1).split('&');
  for (let i = 0; i < getParams.length; i++) {
    const param = getParams[i].split('=');
    if (param[0] === 'partner_link' && partnerLink) {
      partnerLink.value = param[1];
    } else if (param[0] === 'AffiliateCode') {
      affiliateCode.value = param[1];
    } else if (param[0] === 'PromoCode') {
      promoCode.value = param[1];
    } else if (param[0] === 'mnfx_ref_id') {
      mnfxRefId.value = param[1];
    }
  }

  if (affiliateCode.value === '') {
    const jamcom = getCookie('jamcom');
    if (jamcom) {
      affiliateCode.value = jamcom;
    }
  }

  if (partnerLink.value === '') {
    const partnerLinkVal = getCookie('partner_link');
    if (partnerLinkVal) {
      partnerLink.value = partnerLinkVal;
    }
  }

  if (uriQuery) {
    uriQuery.value = window.location.search.slice(1);
  }

  let iti;
  if (phoneNum && window.intlTelInput) {
    iti = window.intlTelInput(phoneNum, {
      utilsScript: srcUtils,
    });
  }

  const errorMap = [
    (window.translations && translations.invalidNumber) ? translations.invalidNumber : 'Invalid number',
    (window.translations && translations.invalidCountryCode) ? translations.invalidCountryCode : 'Invalid country code',
    (window.translations && translations.tooShort) ? translations.tooShort : 'Too short',
    (window.translations && translations.tooLong) ? translations.tooLong : 'Too long',
    (window.translations && translations.invalidNumber) ? translations.invalidNumber : 'Invalid number',
    (window.translations && translations.invalidNumber) ? translations.invalidNumber : 'Invalid number',
  ];

  const countryValidate = () => {
    let strError = '';
    if (!checkValue(countrySelect)) {
      strError = (window.translations && translations.fieldRequired) ? translations.fieldRequired : 'Field is required.';
    }

    if (strError !== '') {
      addClassError(countrySelect);
      showError(countrySelect, strError);
    }

    return strError !== '';
  };

  const phoneNumValidate = () => {
    let strError = '';
    if (!checkValue(phoneNum)) {
      strError = (window.translations && translations.fieldRequired) ? translations.fieldRequired : 'Field is required.';
    } else if (!iti.isValidNumber()) {
      const errorCode = iti.getValidationError();
      strError = errorMap[errorCode];
    }

    if (strError !== '') {
      addClassError(phoneNum);
      showError(phoneNum, strError);
    }

    return strError !== '';
  };

  if (countrySelect) {
    $.ajax({
      type: 'GET',
      url: 'https://www.monfex.com/api/location/countries',
      dataType: 'json',

      success: function (data) {
        const fragment = document.createDocumentFragment();
        const optionCountry = document.createElement('option');
        fragment.appendChild(optionCountry);
        for (let i = 0; i < data.length; i++) {
          const dataItem = data[i];
          const optionCountry = document.createElement('option');
          optionCountry.value = dataItem['country_code'];
          optionCountry.setAttribute('data-code', dataItem['dial_code']);
          optionCountry.setAttribute('data-country', dataItem['name']);
          optionCountry.innerHTML = dataItem['name'];
          if (window.defaultСountry) {
            if (dataItem['name'] === defaultСountry) {
              optionCountry.selected = true;
              country.value = dataItem['name'];

              if (phoneCode) {
                phoneCode.value = '+' + dataItem['dial_code'];
                phoneCode.classList.add('valid');
                iti.setCountry(dataItem.country_code);
              }
            }
          }
          fragment.appendChild(optionCountry);
        }
        countrySelect.appendChild(fragment);

        $(countrySelect).select2({
          placeholder: (window.translations && translations.selectCountry) ? translations.selectCountry : 'Select country',
        });
      },
      error: function error(xhr) {},
    });

    $(countrySelect).on('select2:select', function (e) {
      e.currentTarget.classList.add('valid');
      iti.setCountry(e.params.data.id);
      country.value = e.params.data.element.dataset.country;

      if (phoneCode) {
        phoneCode.value = '+' + e.params.data.element.dataset.code;
        phoneCode.classList.add('valid');
      }

      if (phoneNum) {
        if (iti.isValidNumber()) {
          phoneNum.classList.add('valid');
        } else {
          phoneNum.classList.remove('valid');
        }
      }
    });

    if (phoneNum) {
      phoneNum.addEventListener('input', function (e) {
        let val = e.currentTarget.value;
        if (val && !val.match(/^[\d]+$/)) {
          val = val.replace(/\D/g, '');
        }
        e.currentTarget.value = val.slice(0, 13);
        if (iti.isValidNumber()) {
          phoneNum.classList.add('valid');
        } else {
          phoneNum.classList.remove('valid');
        }
      });

      phoneNum.addEventListener('blur', phoneNumValidate);
    }
  }

  const fnameValidate = () => {
    let strError = '';
    if (!checkValue(fname)) {
      strError = (window.translations && translations.fieldRequired) ? translations.fieldRequired : 'Field is required.';
    } else if (fname.value.trim().length < 2 || fname.value.trim().length > 80 || !regExpName.test(fname.value)) {
      strError = (window.translations && translations.invalidFormat) ? translations.invalidFormat : 'Invalid format.';
    }

    if (strError !== '') {
      addClassError(fname);
      showError(fname, strError);
    }

    return strError !== '';
  };

  if (fname) {
    fname.addEventListener('input', function () {
      const value = fname.value;
      if (value.match(/[^a-zA-Z\-\s]/)) {
        showError(fname, (window.translations && translations.onlyLatinLetters) ? translations.onlyLatinLetters : 'Only latin letters (A-Z) and hyphens (-) are allowed.');
      } else {
        hideError(fname);
      }

      const checkedValue = (value.match(/[^a-zA-Z\-\s]/))
        ? fname.value.replace(/[^a-zA-Z\-\s]/, '').slice(0, 80)
        : value.slice(0, 80);
      fname.value = checkedValue;
      if (checkValue(fname) && checkedValue.trim().length >= 2 && checkedValue.trim().length <= 80 && regExpName.test(checkedValue)) {
        fname.classList.add('valid');
      } else if (fname.classList.contains('valid')) {
        fname.classList.remove('valid');
      }
    });

    fname.addEventListener('blur', fnameValidate);
  }

  const emailValidate = () => {
    let strError = '';
    if (!checkValue(email)) {
      strError = (window.translations && translations.fieldRequired) ? translations.fieldRequired : 'Field is required.';
    } else if (email.value.indexOf('+') >= 0) {
      strError = (window.translations && translations.invalidFormat) ? translations.invalidFormat : 'Invalid format.';
    } else if (!regExpEmail.test(email.value)) {
      strError = (window.translations && translations.invalidFormat) ? translations.invalidFormat : 'Invalid format.';
    }

    if (strError !== '') {
      addClassError(email);
      showError(email, strError);
    }

    return strError !== '';
  };

  if (email) {
    email.addEventListener('input', function () {
      if (checkValue(email) && email.value.indexOf('+') < 0 && regExpEmail.test(email.value)) {
        email.classList.add('valid');
      } else if (email.classList.contains('valid')) {
        email.classList.remove('valid');
      }
    });

    email.addEventListener('blur', emailValidate);
  }

  const passwordValidate = () => {
    let strError = '';

    if (!checkValue(password)) {
      strError = (window.translations && translations.fieldRequired) ? translations.fieldRequired : 'Field is required.';
    } else if (password.value.length < 5 || password.value.length > 15) {
      strError = (window.translations && translations.lengthPassword) ? translations.lengthPassword : 'Length must be 5-15 characters.';
    } else if (!(regExpPass1.test(password.value) || regExpPass2.test(password.value) || regExpPass3.test(password.value) || regExpPass.test(password.value))) {
      strError = (window.translations && translations.invalidPass) ? translations.invalidPass : 'Password must contains only latin characters with at least two of three types of characters (lowercase letters, uppercase letters or digits).';
    }

    if (strError !== '') {
      addClassError(password);
      showError(password, strError);
    }

    return strError !== '';
  };

  if (password) {
    password.addEventListener('input', function (e) {
      let val = e.currentTarget.value;
      let passWrap = e.currentTarget.parentElement;

      if (val === '') {
        passWrap.setAttribute('class', 'form-input-password-wrapper low');
      } else if (val.length < 5) {
        passWrap.setAttribute('class', 'form-input-password-wrapper low');
      } else if (regExpPass.test(val) === true) {
        passWrap.setAttribute('class', 'form-input-password-wrapper high');
      } else if (val.length >= 5) {
        passWrap.setAttribute('class', 'form-input-password-wrapper medium');
      }

      if (checkValue(password) && password.value.length >= 5 && password.value.length <= 15 && (regExpPass1.test(password.value) || regExpPass2.test(password.value) || regExpPass3.test(password.value) || regExpPass.test(password.value))) {
        password.classList.add('valid');
      } else if (password.classList.contains('valid')) {
        password.classList.remove('valid');
      }
    });

    password.addEventListener('blur', passwordValidate);
  }

  const termsValidate = () => {
    let strError = '';
    if (!terms.checked) {
      strError = (window.translations && translations.acceptTerms) ? translations.acceptTerms : 'You must accept "Terms of Service" and "Privacy Policy" in order to complete registration.';
    }

    if (strError !== '') {
      addClassError(terms);
      showError(terms, strError);
    }

    return strError !== '';
  };

  regForm.addEventListener('submit', function (e) {
    e.preventDefault();

    if (btn && btn.classList.contains('waiting')) {
      return;
    }

    let validForm = true;

    if (fname && fnameValidate()) {
      validForm = false;
    }

    if (countrySelect && countryValidate()) {
      validForm = false;
    }

    if (email && emailValidate()) {
      validForm = false;
    }

    if (password && passwordValidate()) {
      validForm = false;
    }

    if (phoneNum && phoneNumValidate()) {
      validForm = false;
    }

    if (terms && termsValidate()) {
      validForm = false;
    }

    if (validForm) {
      if (phone) {
        phone.value = phoneCode.value.replace('+', '') + phoneNum.value;
      }

      $.ajax({
        type: 'POST',
        url: (mnfxRefId.value !== '') ? `${regForm.getAttribute('action')}?mnfx_ref_id=${mnfxRefId.value}` : regForm.getAttribute('action'),
        dataType: 'json',
        data: $(regForm).serialize(),

        beforeSend: function () {
          if (btn) {
            btn.classList.add('waiting');
          }
        },
        complete: function () {
          if (btn) {
            btn.classList.remove('waiting');
          }
        },
        success: function (data) {
          if (data.status === 'success') {
            if (window.customSuccessRedirect && window.successPage) {
              window.location.replace(successPage + window.location.search);
            } else {
              if (data.redirect_link) {
                window.location.replace(data.redirect_link);
              } else if (window.successPage) {
                window.location.replace(successPage + window.location.search);
              } else {
                window.location.replace('https://www.monfex.com/register/success' + window.location.search);
              }
            }
          } else if (data.status === 'error') {
            if (data.error_code === "15001") {
              if (email) {
                addClassError(email);
                showError(email, (window.translations && translations.emailAlreadyExists) ? translations.emailAlreadyExists : 'Email already exists.');
              }
            } else if (data.error_code === "15002") {
              if (phoneNum) {
                addClassError(phoneNum);
                showError(phoneNum, (window.translations && translations.phoneAlreadyUse) ? translations.phoneAlreadyUse : 'This phone number is already in use.');
              }
            } else if (data.error_code === "10000") {
              popupShow((window.translations && translations.somethingWentWrong) ? translations.somethingWentWrong : 'Something Went Wrong. Please try again later.');
            } else {
              popupShow((window.translations && translations.somethingWentWrong) ? translations.somethingWentWrong : 'Something Went Wrong. Please try again later.');
            }
          }
        },
        error: function error(xhr) {
          popupShow((window.translations && translations.somethingWentWrong) ? translations.somethingWentWrong : 'Something Went Wrong. Please try again later.');
        },
      });
    }
  });
};
popup()
// settingRegisterForm(regForm)
